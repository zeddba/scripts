drop tablespace junk including contents and datafiles;
exit
