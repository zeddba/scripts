create table demo_log (when timestamp, comments varchar2(200));
exit
